var div = document.createElement('div');
document.body.appendChild(div);
div.className = 'xxx';
div.innerHTML = '<a href="https://www.sponsorkliks.com/winkels.php?club=3831"><img src="http://hetrsg.nl/images/rsglogo.png" width="35%" height="35%" alt="Koop bij dit bedrijf via Sponserkliks!"></a>';
div.style.position = "fixed";
div.style.bottom = "10px";
div.style.left = "10px";
div.style.zIndex = "10";

//div.style.cssFloat = "right";